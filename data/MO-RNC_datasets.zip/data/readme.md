# Datasets

MO-RNC evaluates continuous representation learning on seven multi-output regression benchmarks: ATP1d, ATP7d, OES10, OES97, SCM1d, SCM20d, and SARCOS.

## Data Preparation

Place the following files directly in this directory before running the training scripts with `--data_folder ./data`.

| Dataset | File | Samples in the supplied ARFF file | Inputs | Outputs | `--dataset` |
| --- | --- | ---: | ---: | ---: | --- |
| ATP1d | `atp1d.arff` | 337 | 411 | 6 | `Atp1d` |
| ATP7d | `atp7d.arff` | 296 | 411 | 6 | `Atp7d` |
| OES10 | `oes10.arff` | 403 | 298 | 16 | `Oes10` |
| OES97 | `oes97.arff` | 334 | 263 | 16 | `Oes97` |
| SCM1d | `scm1d.arff` | 9,803 | 280 | 16 | `scm1d` |
| SCM20d | `scm20d.arff` | 8,966 | 61 | 16 | `scm20d` |
| SARCOS | `Sarcos.arff` | 48,933 | 21 | 7 | `Sarcos` |

File names and dataset arguments are case-sensitive. These seven files store the input attributes first and the target attributes last; `dataset.py` separates them using the dataset-specific output count.


### SCM1d archive

For browser uploads, SCM1d can be distributed as `scm1d.zip`. Extract it so that `scm1d.arff` is directly inside `data`, rather than inside an additional nested folder:

```bash
python -m zipfile -e ./data/scm1d.zip ./data
```

The loader reads the extracted ARFF file, not the ZIP archive.

## Preprocessing and Splits

The paper reports seeds 0–9 and an 80% training / 20% test split. Pass the same seed and split settings to encoder pretraining and linear regression. The scripts estimate input and target standardization statistics from the training partition and reuse them for evaluation. Missing inputs are replaced using feature-wise medians estimated from training data; rows with non-finite targets are removed by the loader. Reported RMSE is computed after transforming predictions back to the original target units.

## Sources

ATP1d, ATP7d, OES10, OES97, SCM1d, and SCM20d are available from the [Mulan multi-target regression collection](https://github.com/tsoumakas/mulan/tree/master/data/multi-target). The accompanying source collection cites:

> E. Spyromitros-Xioufis, G. Tsoumakas, W. Groves, and I. Vlahavas. Multi-Target Regression via Input Space Expansion: Treating Targets as Inputs. Machine Learning, 2016.

SARCOS is an inverse-dynamics benchmark with 21 inputs and seven robot-joint torque targets. The manuscript cites C. E. Rasmussen and C. K. I. Williams, *Gaussian Processes for Machine Learning*, 2006.

See the [main README](../README.md) for the loss interface and two-stage training commands.
